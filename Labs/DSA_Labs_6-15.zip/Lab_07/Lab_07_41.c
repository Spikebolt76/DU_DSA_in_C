#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 100
//====================================================================================
typedef struct {
    char items[MAX];
    int top;
} Stack;

void initStack(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

int isFull(Stack *s) {
    return s->top == MAX - 1;
}

void push(Stack *s, char c) {
    if (!isFull(s)) {
        s->items[++(s->top)] = c;
    }
}

char pop(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[(s->top)--];
    }
    return '\0';
}

char peek(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[s->top];
    }
    return '\0';
}
//======================================================================================
// Write a program to convert infix notation to postfix notation using stack.

int precedence(char op) {
    switch (op) {
        case '^': return 3;
        case '*':
        case '/': return 2;
        case '+':
        case '-': return 1;
        default: return 0;
    }
}

int isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

void infixToPostfix (char *infix, char* *postfix) {
    Stack *s;
    initStack(s);
    int i = 0, j = 0;
    char c;

    while (infix[i] != '\0') {
        c = infix[i];

        if (isalnum(c)) {
            postfix[j++] = c;
        }
        else if (c == '(') {
            push(s, c);
        }
        else if (c == ')') {
            while (!isEmpty(s) && peek(s) != '(') {
                postfix[j++] = pop(s);
            }
            if (isEmpty(&s)) {
                printf("Error: Unmatched closing parenthesis\n");
                postfix[0] = '\0'; 
                return;
            }

            pop(s);
        }
        else if (isOperator(c)) {
            while (!isEmpty(s) && peek(s) != '(' && (precedence()) {

            }
        }
        else {
            printf("Error: Invalid character '%c'\n", c);
            postfix[0] = '\0'; 
            return;
        }
        i++;
    }
}

int main () {
}