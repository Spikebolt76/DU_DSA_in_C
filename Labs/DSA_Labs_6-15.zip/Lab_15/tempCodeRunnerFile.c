insertAtTail(list, 67);
    // insertAtTail(list, 0);
    // insertAtTail(list, 23);